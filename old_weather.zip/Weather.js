import React from "react";
import {StyleSheet, Text, View, StatusBar} from "react-native";
import PropTypes from "prop-types";
import {LinearGradient} from "expo-linear-gradient";
import {MaterialCommunityIcons, Fontisto, Ionicons, Entypo} from "@expo/vector-icons";

const airOptions = {
    1: {
        gradient: ["#5cd5ed", "#1022ff"]
    },
    2: {
        gradient: ["#1fe5A8", "#209fff"]
    },
    3: {
        gradient: ["#FFC023", "#20c982"]
    },
    4: {
        gradient: ["#ffbf23", "#fa3909"]
    },
    5: {
        gradient: ["#ff6a00", "#ee0979"]
    }
}

const weatherOptions = {
    Thunderstorm: {
        iconName: "weather-lightning"
    },
    Drizzle: {
        iconName: "weather-hail"
    },
    Rain: {
        iconName: "weather-rainy"
    },
    Snow: {
        iconName: "weather-snowy"
    },
    Atmosphere: {
        iconName: "weather-hail"
    },
    Clear: {
        iconName: "weather-sunny"
    },
    Clouds: {
        iconName: "weather-cloudy"
    },
    Mist: {
        iconName: "weather-hail"
    },
    Dust: {
        iconName: "weather-hail"
    },
    Haze: {
        iconName: "weather-hail"
    }
};

export default function Weather({
    temp,
    condition,
    aqi,
    windspeed,
    winddeg,
    humidity,
    pop1,
    pop2,
    pop3,
    rain,
    snow,
    y_dt,
    y_temp,
    y_condition,
    y_temp_d
}) {
    return (
        <LinearGradient colors={airOptions[3].gradient} style={styles.container}>
            <StatusBar barStyle="light-content"/>
            <View style={styles.black} />
            <View style={styles.black} />
            <View style={styles.topcontainer}>
                <Text style={styles.subtitle}>
                    ddsddfdsf sf dsfdsf ds
                </Text>
            </View>
            <View style={styles.maincontainer}>
                <View style={styles.main}>
                    <View style={styles.mainicon}>
                        <MaterialCommunityIcons name={weatherOptions[condition].iconName} size={165} color="white"/>
                        </View>
                    <View style={styles.maintext}>
                        <View style={styles.mtext}>
                            <Text style={styles.maintext_f}>{temp}℃</Text>
                        </View>
                        <View style={styles.context}>
                        <Text style={styles.con_f}>sdf v</Text>
                        </View>
                    </View>
                </View>
                <View style={styles.else} />
                <View style={styles.ex_pic}>
                    <View style={styles.ex_pic_each}>
                        <Fontisto name="wind" size={40} color="white"/>
                    </View>
                    <View style={styles.ex_pic_each}>
                        <MaterialCommunityIcons name="cup" size={45} color="white"/>
                    </View>
                    <View style={styles.ex_pic_each}>
                        <Ionicons name="md-water" size={45} color="white"/>
                    </View>
                    <View style={styles.ex_pic_each}>
                        <Ionicons name="ios-snow" size={45} color="white"/>
                    </View>
                </View>
                <View style={styles.ex_pic}>
                    <View style={styles.ex_text_each}>
                        <Text style={styles.ex_f}>{windspeed}m/s</Text>
                    </View>
                    <View style={styles.ex_text_each}>
                        <Text style={styles.ex_f}>{humidity}%</Text>
                    </View>
                    <View style={styles.ex_text_each}>
                        <Text style={styles.ex_f}>{rain}0.0mm</Text>
                    </View>
                    <View style={styles.ex_text_each}>
                        <Text style={styles.ex_f}>{snow}0.0mm</Text>
                    </View>
                </View>
            </View>
            <View style={styles.bottomcontainer}>
                <View style={styles.bot_dt}>
                    <Text style={styles.bot_dt_f}> {y_dt} </Text>
                </View>
                <View style={styles.bot_icon}>
                    <MaterialCommunityIcons name={weatherOptions[condition].iconName} size={73} color="white"/>
                </View>
                <View style={styles.bot_m}>
                    <Text style={styles.bot_max_f}>{y_temp}°</Text>
                </View>
                <View style={styles.bot_m}>
                    <Text style={styles.bot_min_f}>{y_temp_d}°</Text>
                </View>
                <View style={styles.bot_watericon}>
                    <MaterialCommunityIcons name="water" size={25} color="white" />
                </View>
                <View style={styles.bot_water}>
                    <Text style={styles.bot_water_f}>100%</Text>
                </View>
            </View>
            <Text style={styles.bot_dt_f}> {y_dt} </Text>
            <View style={styles.bottomcontainer}>
                <Text style={styles.subtitle}>
                    {pop1}%
                </Text>
            </View>
            <View style={styles.bottomcontainer}>
                <Text style={styles.subtitle}>
                    {pop2}%
                </Text>
            </View>
            <View style={styles.bottomcontainer}>
                <Text style={styles.subtitle}>
                    {pop3}%
                </Text>
            </View>
            <View style={styles.black} />
        </LinearGradient>
    );
}

Weather.propTypes = {
    temp: PropTypes.number.isRequired,
    y_temp: PropTypes.number.isRequired,
    condition: PropTypes
        .oneOf([
            "Thunderstorm",
            "Drizzle",
            "Rain",
            "Snow",
            "Atmosphere",
            "Clear",
            "Clouds",
            "Mist",
            "Dust",
            "Haze"
        ])
        .isRequired,
    aqi: PropTypes.number.isRequired,
    windspeed: PropTypes.number.isRequired,
    winddeg: PropTypes.number.isRequired
};

const styles = StyleSheet.create({
    container: {
        flex: 1
    },
    black:{
        height: "2%",
        //backgroundColor: "yellow"
    },
    else: {
        height: "6%",
        //backgroundColor: "orange"
    },
    topcontainer: {
        height: "12%",
        alignItems: "center",
        justifyContent: "center",
        //backgroundColor: "blue"
    },
    maincontainer: {
        height: "36%",
        //backgroundColor: "green"
    },
    main: {
        height: "55%",
        flexDirection: "row",
        justifyContent: "center",
        //backgroundColor: "blue"
    },
    mainicon: {
        width: "45%",
        alignItems: "center",
        justifyContent: "center",
        //backgroundColor: "red"
    },
    maintext: {
        width: "45%",
        justifyContent: "center",
        alignItems: "center",
        //backgroundColor: "orange"
    },

    mtext: {
        height: "40%",
        //backgroundColor: "black",
    },
    maintext_f: {
        color: "white",
        fontSize: 62,
        fontWeight: "800"
    },
    context: {
        //backgroundColor: "blue"
    },
    con_f: {
        color: "white",
        fontSize: 30,
        fontWeight: "600"
    },

    ex_pic: {
        height: "17%",
        flexDirection: "row",
        justifyContent: "center",
        //backgroundColor: "pink"
    },
    ex_pic_each: {
        width: "25%",
        justifyContent: "center",
        alignItems: "center",
        //backgroundColor: "red"
    },
    ex_text_each: {
        width: "25%",
        height: "70%",
        justifyContent: "center",
        alignItems: "center",
        //backgroundColor: "red"
    },
    ex_f:
    {
        color: "white",
        fontSize: 21,
        fontWeight: "600"
    },

    bottomcontainer: {
        height: "10%",
        alignItems: "center",
        justifyContent: "center",
        flexDirection: "row",
        //backgroundColor: "blue"
    },
    bot_dt: {
        width: "20%",
        alignItems: "center",
        //backgroundColor: "pink"
    },
    bot_icon: {
        width: "25%",
        alignItems: "center",
        paddingRight: 3,
        //backgroundColor: "black"
    },
    bot_m: {
        width: "13%",
        alignItems: "center",
        //backgroundColor: "red"
    },
    bot_watericon: {
        width: "11%",
        alignItems: "flex-end",
        paddingRight: 5,
        //backgroundColor: "purple"
    },
    bot_water: {
        width: "18%",
        alignItems: "flex-start",
        //backgroundColor: "gray"
    },

    bot_dt_f: {
        fontSize: 24,
        color: "white",
        fontWeight: "800"
    },
    bot_max_f: {
        fontSize: 25,
        color: "white",
        fontWeight: "600"
    },
    bot_min_f:
    {
        fontSize: 25,
        color: "#cccccc",
        fontWeight: "600"
    },
    bot_water_f: {
        fontWeight: "500",
        color: "white",
        fontSize: 20
    }
});