import React from 'react';
import {Alert} from "react-native";
import Loading from './Loading';
import * as Location from "expo-location";
import axios from 'axios';
import Weather from './Weather';

const API_KEY = "0e0ca57ab5b535a16c8a161c2222ca56";

const now = new Date();
const yes = Math.floor(new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1)) / 1000 + 43200;
const yes_d = Math.floor(new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1)) / 1000;

export default class extends React.Component {
    state = {
        isLoading: true
    };

    getWeather = async (latitude, longitude) => {
        const {
            data: {
                current,
                daily
            }
        } = await axios.get(
            `https://api.openweathermap.org/data/2.5/onecall?lat=${latitude}&lon=${longitude}&exclude=minutely,hourly&appid=${API_KEY}&units=metric`
        );
        this.setState({
            isLoading: false,
            condition: current.weather[0].main,
            temp: current.temp,
            speed: current.wind_speed,
            deg: current.wind_deg,
            humidity: current.humidity,
            pop1: daily[0].pop,
            pop2: daily[1].pop,
            pop3: daily[2].pop
            //rain: current.rain['1h'],
            //snow: current.snow['1h'],
        });
    };
    getYesterday = async (latitude, longitude) => {
        const {
            data: {current}
        } = await axios.get(
            `https://api.openweathermap.org/data/2.5/onecall/timemachine?lat=${latitude}&lon=${longitude}&dt=${yes}&appid=${API_KEY}&units=metric`
        );
        this.setState({
            y_dt: current.dt,
            y_condition: current.weather[0].main,
            y_temp: current.temp
        });
    };
    getYesterday_d = async (latitude, longitude) => {
        const {
            data: {current}
        } = await axios.get(
            `https://api.openweathermap.org/data/2.5/onecall/timemachine?lat=${latitude}&lon=${longitude}&dt=${yes_d}&appid=${API_KEY}&units=metric`
        );
        this.setState({
            y_temp_d: current.temp
        });
    };
    getAirPollution = async (latitude, longitude) => {
        const {data: {
                list
            }} = await axios.get(
            `https://api.openweathermap.org/data/2.5/air_pollution?lat=${latitude}&lon=${longitude}&appid=${API_KEY}&units=metric`
        );
        this.setState({aqi: list[0].main.aqi});
    };

    getLocation = async () => {
        try {
            await Location.getForegroundPermissionsAsync();
            const {
                coords: {
                    latitude,
                    longitude
                }
            } = await Location.getCurrentPositionAsync();
            this.getWeather(latitude, longitude)
            this.getYesterday(latitude, longitude)
            this.getYesterday_d(latitude, longitude)
            this.getAirPollution(latitude, longitude)
        } catch (error) {
            Alert.alert("Can't find you.", "So sad");
        }
    };
    componentDidMount() {
        this.getLocation();
    }
    render() {
        const {
            isLoading,
            temp,
            condition,
            aqi,
            speed,
            deg,
            humidity,
            pop1, pop2, pop3, rain, snow, y_dt, y_temp, y_condition, y_temp_d
        } = this.state;
        return isLoading
            ? <Loading/>
            : (
                <Weather
                    temp={Math.round(temp)}
                    condition={condition}
                    aqi={aqi}
                    windspeed={speed.toFixed(1)}
                    winddeg={deg}
                    humidity={humidity}
                    pop1={pop1*100}
                    pop2={pop2*100}
                    pop3={pop3*100}
                    //rain={rain.toFixed(1)}
                    //snow={snow.toFixed(1)}
                    y_dt={y_dt*1000}
                    //y_dt={now.getDate()}
                    y_temp={Math.round(y_temp)}
                    y_condition={y_condition}
                    y_temp_d={Math.round(y_temp_d)}
                    />
            );
    }
}