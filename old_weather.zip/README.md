# React_Native_Weather_App

Weather app with **[React Native](https://reactnative.dev/)** using **[openweathermap api](https://openweathermap.org/api)**

- [ ] background color adjustment (gray tone)
- [ ] delete UV
- [ ] check errors

:label:  Updating...

[↩️ Go Back](https://github.com/lisy0123/Nomadcoders)

